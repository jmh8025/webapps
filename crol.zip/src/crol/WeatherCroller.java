package crol;

import java.io.File;
import java.util.HashMap;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;




public class WeatherCroller {
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		WeatherSearch ws = new WeatherSearch();
		HashMap<String, Object> days = new HashMap<String, Object>();

		String juso[][] = { { "37.4968436,127.0329199", "\"����\"" }, // ����
	/*			{ "37.4569323,126.6308482", "\"��õ\"" }, // ��õ
				{ "35.1595726,126.8267877", "\"����\"" }, // ����
				{ "35.8671885,128.5852423", "\"�뱸\"" }, // �뱸
				{ "36.3730796,127.31876", "\"����\"" }, // ����
				{ "35.1777341,129.0488983", "\"�λ�\"" }, // �λ�
				{ "37.733571,128.260816", "\"������\"" }, // ������
				{ "37.2412612,127.1762173", "\"��⵵\"" }, // ��⵵
				{ "36.7579883,127.6397657", "\"��û�ϵ�\"" }, // ��û�ϵ�
				{ "36.5360354,126.2333867", "\"��û����\"" }, // ��û����
				{ "35.7262841,126.369576", "\"����ϵ�\"" }, // ����ϵ�
				{ "34.694849,125.9375717", "\"���󳲵�\"" }, // ���󳲵�
				{ "36.4797975,128.8122476", "\"���ϵ�\"" }, // ���ϵ�
				{ "35.337744,128.2455522", "\"��󳲵�\"" }, // ��󳲵�
				{ "33.4031006,126.5013746", "\"���ֵ�\"" }// ���ֵ�
*/		};

		String appKeyId = "0b2ef5c7-2fe0-3a70-b5b5-065e223a3a57";

		for (int i = 0; i < juso.length; i++) {
			HashMap<String, Object> days3 = new HashMap<String, Object>(); // ���ú��� 2����(3��ġ)
			HashMap<String, Object> days7 = new HashMap<String, Object>(); // 3���ĺ��� 9���ı���
			int idx = juso[i][0].indexOf(",");
			double lat, lon;
			lat = Double.parseDouble(juso[i][0].substring(0, idx));
			lon = Double.parseDouble(juso[i][0].substring(idx + 1));
			days3 = ws.day3(lat, lon, appKeyId);
			days7 = ws.day7(lat, lon, appKeyId);
			days7.putAll(days3);
			days.put(juso[i][1], days7);
		}
		//hashmap�� jsonȭ ���ѹ�����
		String test = days.toString().replaceAll("=",":");

		
		
		//���Ͼ���
        DataOutputStream dos = null;
        try {
        	File targetFile = new File("juso.json");
        	targetFile.createNewFile();
        	BufferedWriter output = new BufferedWriter(new OutputStreamWriter(new FileOutputStream(targetFile.getPath()), "UTF8"));
        	output.write(test);
        	output.close();
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            if (dos != null) try { dos.close(); } catch (IOException e) {}
        }
        try{
        	FileInputStream fis = new FileInputStream(new File("juso.json")); 
        	InputStreamReader isr = new InputStreamReader(fis,"UTF-8"); 
        	BufferedReader br = new BufferedReader(isr);	
        	while(true){
        		String str = br.readLine();
        		if(str==null) break;
        		System.out.println(str);
        	}
        }catch(Exception e){
        	e.printStackTrace();
        }
        
        
	}
}
